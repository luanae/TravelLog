import { Component, inject, OnInit } from "@angular/core";
import { RouterLink, Router, ActivatedRoute } from "@angular/router";
import { FormBuilder, ReactiveFormsModule, Validators } from "@angular/forms";
import { ViagensService } from "../../core/services/viagens.service";
import { Viagem } from "../../core/models/viagem.model";

@Component({
  selector: "app-manutencao-viagem",
  imports: [RouterLink, ReactiveFormsModule],
  templateUrl: "./manutencao-viagem.html",
  styleUrl: "./manutencao-viagem.css",
})
export class ManutencaoViagem implements OnInit {
  private fb = inject(FormBuilder);
  private viagemService = inject(ViagensService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);

  editingId: string | null = null;
  loading = false;
  loadingData = false;
  sucessMessage = "";
  errorMessage = "";

  form = this.fb.nonNullable.group({
    cidade: ["", [Validators.required, Validators.minLength(3)]],
    pais: ["", [Validators.required]],
    dataViagem: ["", [Validators.required]],
    avaliacao: [0, [Validators.required, Validators.min(1), Validators.max(5)]],
    relato: ["", [Validators.required]],
    meioTransporte: ["", [Validators.required]],
    favorita: [false],
  });

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get("id");
    if (id) {
      this.editingId = id;
      this.loadViagem(id);
    }
  }

  loadViagem(id: string): void {
    this.loadingData = true;
    this.viagemService.getById(id).subscribe({
      next: (viagem) => {
        this.form.patchValue({
          cidade: viagem.cidade,
          pais: viagem.pais,
          dataViagem: viagem.dataViagem,
          avaliacao: viagem.avaliacao,
          relato: viagem.relato,
          meioTransporte: viagem.meioTransporte,
          favorita: viagem.favorita,
        });
        this.loadingData = false;
      },
      error: (error) => {
        this.errorMessage = "Erro ao carregar viagem: " + error.message;
        this.loadingData = false;
      },
    });
  }

  submit(): void {
    this.sucessMessage = "";
    this.errorMessage = "";
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.loading = true;
    const formValue = this.form.getRawValue();
    const viagemData: Omit<Viagem, "id"> = {
      cidade: formValue.cidade,
      pais: formValue.pais,
      dataViagem: formValue.dataViagem,
      avaliacao: Number(formValue.avaliacao),
      relato: formValue.relato,
      meioTransporte: formValue.meioTransporte,
      favorita: formValue.favorita,
    };

    const requisicao =
      this.editingId !== null
        ? this.viagemService.update(this.editingId, viagemData)
        : this.viagemService.create(viagemData);

    requisicao.subscribe({
      next: () => {
        this.loading = false;
        this.sucessMessage =
          this.editingId !== null
            ? "Viagem atualizada com sucesso!"
            : "Viagem cadastrada com sucesso!";
        setTimeout(() => this.router.navigate(["/admin"]), 1000);
      },
      error: (error) => {
        this.loading = false;
        this.errorMessage = "Erro ao salvar viagem: " + error.message;
      },
    });
  }
}
